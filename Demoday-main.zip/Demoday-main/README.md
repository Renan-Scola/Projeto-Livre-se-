// Demoday

// Somos uma equipe formada através do Instituto Proa, cujo principal objetivo é incentivar a leitura e dar acessibilidade ao estudo, por meio de um website de interação com usuários que  desejam  doar ou receber livros, e também o acesso amplo de conteúdos didáticos gratuitos e  on-line.

// Integrantes: Amanda Kethelyn Vieira Chagas, Gisele Silvestre de Lima, Aline Aparecida Mattos de Maia, Isaias José de Souza, Renan Godoi Pereira Scola, Lucas Freitas Bezerra, Victoria de Carvalho Dantas
